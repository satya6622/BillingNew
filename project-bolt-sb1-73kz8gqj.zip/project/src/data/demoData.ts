import { User, SareeItem, Bill, StaffMember, QrCode, RecentActivity, SalesSummary } from '../types';
import { format, subDays, subHours, subMonths } from 'date-fns';

// Demo Users
export const demoUsers: User[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@sareeshop.com',
    role: 'admin',
    avatarUrl: 'https://randomuser.me/api/portraits/women/44.jpg',
  },
  {
    id: '2',
    name: 'Staff User',
    email: 'staff@sareeshop.com',
    role: 'staff',
    avatarUrl: 'https://randomuser.me/api/portraits/men/32.jpg',
  },
];

// Demo Saree Items
export const demoSareeItems: SareeItem[] = [
  {
    id: '1',
    name: 'Banarasi Silk Saree',
    sku: 'BAN001',
    price: 15999,
    quantity: 12,
    description: 'Handwoven Banarasi silk saree with gold zari work',
    imageUrl: 'https://images.pexels.com/photos/4937464/pexels-photo-4937464.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=BAN001',
    createdAt: format(subMonths(new Date(), 2), 'yyyy-MM-dd\'T\'HH:mm:ss'),
    updatedAt: format(subDays(new Date(), 15), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '2',
    name: 'Kanjivaram Silk Saree',
    sku: 'KAN002',
    price: 25999,
    quantity: 8,
    description: 'Traditional Kanjivaram silk saree with temple border',
    imageUrl: 'https://images.pexels.com/photos/6766273/pexels-photo-6766273.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=KAN002',
    createdAt: format(subMonths(new Date(), 1), 'yyyy-MM-dd\'T\'HH:mm:ss'),
    updatedAt: format(subDays(new Date(), 5), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '3',
    name: 'Mysore Silk Saree',
    sku: 'MYS003',
    price: 8999,
    quantity: 15,
    description: 'Pure Mysore silk saree with contrast border',
    imageUrl: 'https://images.pexels.com/photos/7959604/pexels-photo-7959604.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=MYS003',
    createdAt: format(subMonths(new Date(), 3), 'yyyy-MM-dd\'T\'HH:mm:ss'),
    updatedAt: format(subMonths(new Date(), 1), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '4',
    name: 'Chanderi Cotton Silk',
    sku: 'CHA004',
    price: 5999,
    quantity: 20,
    description: 'Lightweight Chanderi cotton-silk blend with zari border',
    imageUrl: 'https://images.pexels.com/photos/3810824/pexels-photo-3810824.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=CHA004',
    createdAt: format(subMonths(new Date(), 2), 'yyyy-MM-dd\'T\'HH:mm:ss'),
    updatedAt: format(subDays(new Date(), 20), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '5',
    name: 'Sambalpuri Ikat Saree',
    sku: 'SAM005',
    price: 7499,
    quantity: 10,
    description: 'Handloom Sambalpuri Ikat with traditional motifs',
    imageUrl: 'https://images.pexels.com/photos/8285047/pexels-photo-8285047.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=SAM005',
    createdAt: format(subMonths(new Date(), 4), 'yyyy-MM-dd\'T\'HH:mm:ss'),
    updatedAt: format(subDays(new Date(), 10), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
];

// Demo Bills
export const demoBills: Bill[] = [
  {
    id: '1',
    billNumber: 'BILL-001',
    customer: {
      name: 'Priya Sharma',
      contact: '9876543210',
      email: 'priya@example.com',
    },
    items: [
      {
        id: '1',
        sareeId: '1',
        name: 'Banarasi Silk Saree',
        price: 15999,
        quantity: 1,
        subtotal: 15999,
      },
    ],
    subtotal: 15999,
    gstAmount: 800,
    total: 16799,
    createdBy: 'Admin User',
    createdAt: format(subHours(new Date(), 3), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '2',
    billNumber: 'BILL-002',
    customer: {
      name: 'Anjali Patel',
      contact: '8765432109',
      whatsapp: '8765432109',
    },
    items: [
      {
        id: '2',
        sareeId: '2',
        name: 'Kanjivaram Silk Saree',
        price: 25999,
        quantity: 1,
        subtotal: 25999,
      },
      {
        id: '3',
        sareeId: '4',
        name: 'Chanderi Cotton Silk',
        price: 5999,
        quantity: 1,
        subtotal: 5999,
      },
    ],
    subtotal: 31998,
    gstAmount: 1600,
    total: 33598,
    createdBy: 'Staff User',
    createdAt: format(subDays(new Date(), 1), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '3',
    billNumber: 'BILL-003',
    customer: {
      name: 'Meera Iyer',
      contact: '7654321098',
    },
    items: [
      {
        id: '4',
        sareeId: '3',
        name: 'Mysore Silk Saree',
        price: 8999,
        quantity: 2,
        subtotal: 17998,
      },
    ],
    subtotal: 17998,
    gstAmount: 900,
    total: 18898,
    createdBy: 'Admin User',
    createdAt: format(subDays(new Date(), 2), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
];

// Demo Staff Members
export const demoStaffMembers: StaffMember[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@sareeshop.com',
    mobile: '9876543210',
    role: 'admin',
    status: 'active',
    createdAt: format(subMonths(new Date(), 6), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '2',
    name: 'Staff User',
    email: 'staff@sareeshop.com',
    mobile: '8765432109',
    role: 'staff',
    status: 'active',
    createdAt: format(subMonths(new Date(), 3), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '3',
    name: 'Ravi Kumar',
    email: 'ravi@sareeshop.com',
    mobile: '7654321098',
    role: 'staff',
    status: 'inactive',
    createdAt: format(subMonths(new Date(), 2), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
];

// Demo QR Codes
export const demoQrCodes: QrCode[] = [
  {
    id: '1',
    sareeId: '1',
    sareeName: 'Banarasi Silk Saree',
    price: 15999,
    imageUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=BAN001',
    generatedAt: format(subDays(new Date(), 15), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '2',
    sareeId: '2',
    sareeName: 'Kanjivaram Silk Saree',
    price: 25999,
    imageUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=KAN002',
    generatedAt: format(subDays(new Date(), 5), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '3',
    sareeId: '3',
    sareeName: 'Mysore Silk Saree',
    price: 8999,
    imageUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=MYS003',
    generatedAt: format(subMonths(new Date(), 1), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '4',
    sareeId: '4',
    sareeName: 'Chanderi Cotton Silk',
    price: 5999,
    imageUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=CHA004',
    generatedAt: format(subDays(new Date(), 20), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '5',
    sareeId: '5',
    sareeName: 'Sambalpuri Ikat Saree',
    price: 7499,
    imageUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=SAM005',
    generatedAt: format(subDays(new Date(), 10), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
];

// Demo Recent Activities
export const demoRecentActivities: RecentActivity[] = [
  {
    id: '1',
    type: 'bill',
    action: 'created',
    user: 'Admin User',
    details: 'Created bill BILL-001 for Priya Sharma (₹16,799)',
    timestamp: format(subHours(new Date(), 3), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '2',
    type: 'stock',
    action: 'updated',
    user: 'Admin User',
    details: 'Updated stock for Kanjivaram Silk Saree (Qty: 8)',
    timestamp: format(subHours(new Date(), 5), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '3',
    type: 'bill',
    action: 'created',
    user: 'Staff User',
    details: 'Created bill BILL-002 for Anjali Patel (₹33,598)',
    timestamp: format(subDays(new Date(), 1), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '4',
    type: 'staff',
    action: 'login',
    user: 'Staff User',
    details: 'Staff User logged in',
    timestamp: format(subHours(new Date(), 1), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
  {
    id: '5',
    type: 'bill',
    action: 'created',
    user: 'Admin User',
    details: 'Created bill BILL-003 for Meera Iyer (₹18,898)',
    timestamp: format(subDays(new Date(), 2), 'yyyy-MM-dd\'T\'HH:mm:ss'),
  },
];

// Demo Sales Summary
export const demoSalesSummary: SalesSummary = {
  todayTotal: 16799,
  todayBills: 1,
  todayGst: 800,
  weekTotal: 69295,
  monthTotal: 132540,
};