import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter as Router } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import App from './App';
import { AuthProvider } from './contexts/AuthContext';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Router>
      <AuthProvider>
        <App />
        <Toaster 
          position="top-right"
          toastOptions={{
            duration: 4000,
            className: 'toast',
            success: {
              className: 'toast bg-success-100 text-success-800',
            },
            error: {
              className: 'toast bg-error-100 text-error-800',
              duration: 5000,
            },
            loading: {
              className: 'toast bg-neutral-100 text-neutral-800',
            },
          }}
        />
      </AuthProvider>
    </Router>
  </StrictMode>
);