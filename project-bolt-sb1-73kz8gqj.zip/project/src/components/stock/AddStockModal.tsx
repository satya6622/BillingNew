import React, { useState } from 'react';
import { X, Printer, Save } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import toast from 'react-hot-toast';

interface AddStockModalProps {
  onClose: () => void;
  initialData?: {
    id: string;
    name: string;
    sku: string;
    price: number;
    quantity: number;
    description?: string;
  };
  isEdit?: boolean;
}

const AddStockModal: React.FC<AddStockModalProps> = ({ onClose, initialData, isEdit = false }) => {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    sku: initialData?.sku || '',
    price: initialData?.price || 0,
    quantity: initialData?.quantity || 1,
    description: initialData?.description || '',
    numberOfStickers: 1,
    generateQr: true
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? Number(value) : value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.sku || formData.price <= 0) {
      toast.error('Please fill all required fields');
      return;
    }

    // In a real app, this would save to your backend
    toast.success(`${isEdit ? 'Updated' : 'Added'} stock successfully`);
    
    if (formData.generateQr) {
      toast.success(`Generated ${formData.numberOfStickers} QR code sticker(s)`);
    }
    
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-neutral-900 bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-elevated max-w-2xl w-full animate-fade-in animate-slide-in">
        <div className="flex justify-between items-center p-6 border-b border-neutral-200">
          <h3 className="text-xl font-semibold">
            {isEdit ? 'Edit Stock Item' : 'Add New Stock'}
          </h3>
          <button 
            onClick={onClose}
            className="text-neutral-500 hover:text-neutral-700"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <Input
                label="Saree Name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="Enter saree name"
                required
              />

              <Input
                label="SKU/Code"
                name="sku"
                value={formData.sku}
                onChange={handleInputChange}
                placeholder="Enter unique code"
                required
              />

              <Input
                label="Price"
                name="price"
                type="number"
                value={formData.price}
                onChange={handleInputChange}
                placeholder="Enter price"
                required
              />

              <Input
                label="Quantity"
                name="quantity"
                type="number"
                value={formData.quantity}
                onChange={handleInputChange}
                placeholder="Enter quantity"
                required
              />
            </div>

            <div className="space-y-4">
              <div>
                <label className="form-label">Description</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Enter description"
                  className="input-field h-32 resize-none"
                />
              </div>

              <div className="p-4 bg-neutral-50 rounded-lg space-y-4">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="generateQr"
                    name="generateQr"
                    checked={formData.generateQr}
                    onChange={(e) => setFormData(prev => ({ ...prev, generateQr: e.target.checked }))}
                    className="h-4 w-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
                  />
                  <label htmlFor="generateQr" className="ml-2 block text-sm text-neutral-700">
                    Generate QR Code Stickers
                  </label>
                </div>

                {formData.generateQr && (
                  <Input
                    label="Number of Stickers"
                    name="numberOfStickers"
                    type="number"
                    min="1"
                    value={formData.numberOfStickers}
                    onChange={handleInputChange}
                  />
                )}
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 mt-6">
            <Button 
              variant="outline"
              onClick={onClose}
              type="button"
            >
              Cancel
            </Button>
            
            {formData.generateQr && (
              <Button
                variant="secondary"
                type="submit"
                leftIcon={<Printer size={16} />}
              >
                Save & Print QR
              </Button>
            )}
            
            <Button
              type="submit"
              leftIcon={<Save size={16} />}
            >
              {isEdit ? 'Update Stock' : 'Add Stock'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddStockModal;