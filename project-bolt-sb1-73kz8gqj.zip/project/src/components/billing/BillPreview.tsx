import React from 'react';
import { X, Printer, Send } from 'lucide-react';
import Button from '../ui/Button';
import { Bill } from '../../types';

interface BillPreviewProps {
  bill: Bill;
  onClose: () => void;
  onPrint: () => void;
  onSend: () => void;
}

const BillPreview: React.FC<BillPreviewProps> = ({ bill, onClose, onPrint, onSend }) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const formatTime = (dateStr: string) => {
    return new Date(dateStr).toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="fixed inset-0 bg-neutral-900 bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-elevated max-w-2xl w-full animate-fade-in animate-slide-in">
        <div className="flex justify-between items-center p-6 border-b border-neutral-200">
          <h3 className="text-xl font-semibold">Bill Preview</h3>
          <button 
            onClick={onClose}
            className="text-neutral-500 hover:text-neutral-700"
          >
            <X size={20} />
          </button>
        </div>

        <div className="p-6">
          {/* Bill Header */}
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-primary-900">Saree Shop</h2>
            <p className="text-neutral-600">Premium Saree Collection</p>
            <p className="text-sm text-neutral-500">123 Fashion Street, City - 123456</p>
            <p className="text-sm text-neutral-500">Phone: +91 98765 43210</p>
          </div>

          {/* Bill Details */}
          <div className="flex justify-between text-sm mb-6">
            <div>
              <p><strong>Bill No:</strong> {bill.billNumber}</p>
              <p><strong>Date:</strong> {formatDate(bill.createdAt)}</p>
              <p><strong>Time:</strong> {formatTime(bill.createdAt)}</p>
            </div>
            <div className="text-right">
              <p><strong>Customer:</strong> {bill.customer.name}</p>
              <p><strong>Contact:</strong> {bill.customer.contact}</p>
              {bill.customer.email && <p><strong>Email:</strong> {bill.customer.email}</p>}
            </div>
          </div>

          {/* Items Table */}
          <table className="w-full mb-6">
            <thead className="border-b border-neutral-200">
              <tr className="text-sm text-neutral-600">
                <th className="py-2 text-left">Item</th>
                <th className="py-2 text-right">Price</th>
                <th className="py-2 text-center">Qty</th>
                <th className="py-2 text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {bill.items.map((item) => (
                <tr key={item.id} className="border-b border-neutral-100">
                  <td className="py-2">{item.name}</td>
                  <td className="py-2 text-right">{formatCurrency(item.price)}</td>
                  <td className="py-2 text-center">{item.quantity}</td>
                  <td className="py-2 text-right">{formatCurrency(item.subtotal)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Totals */}
          <div className="space-y-2 text-right mb-6">
            <p className="text-neutral-600">
              Subtotal: {formatCurrency(bill.subtotal)}
            </p>
            <p className="text-neutral-600">
              GST (5%): {formatCurrency(bill.gstAmount)}
            </p>
            <p className="text-xl font-bold text-primary-900">
              Total: {formatCurrency(bill.total)}
            </p>
          </div>

          {/* Footer */}
          <div className="text-center text-sm text-neutral-500 mb-6">
            <p>Thank you for shopping with us!</p>
            <p>Visit again</p>
          </div>
        </div>

        <div className="flex justify-end gap-3 p-6 border-t border-neutral-200">
          <Button 
            variant="outline"
            onClick={onClose}
          >
            Close
          </Button>
          <Button
            variant="secondary"
            leftIcon={<Send size={16} />}
            onClick={onSend}
          >
            Send
          </Button>
          <Button
            leftIcon={<Printer size={16} />}
            onClick={onPrint}
          >
            Print
          </Button>
        </div>
      </div>
    </div>
  );
};

export default BillPreview;