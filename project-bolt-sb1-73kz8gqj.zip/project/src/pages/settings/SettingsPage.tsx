import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Lock, Save, User } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import toast from 'react-hot-toast';

const SettingsPage: React.FC = () => {
  const { currentUser } = useAuth();
  
  // Password change state
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  
  const [passwordErrors, setPasswordErrors] = useState<{
    currentPassword?: string;
    newPassword?: string;
    confirmPassword?: string;
  }>({});
  
  // Profile data state
  const [profileData, setProfileData] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    mobile: '9876543210', // Demo value
  });
  
  // Handle password input change
  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({ ...prev, [name]: value }));
  };
  
  // Handle profile input change
  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileData(prev => ({ ...prev, [name]: value }));
  };
  
  // Validate password change
  const validatePasswordChange = () => {
    const errors: {
      currentPassword?: string;
      newPassword?: string;
      confirmPassword?: string;
    } = {};
    
    if (!passwordData.currentPassword) {
      errors.currentPassword = 'Current password is required';
    }
    
    if (!passwordData.newPassword) {
      errors.newPassword = 'New password is required';
    } else if (passwordData.newPassword.length < 8) {
      errors.newPassword = 'Password must be at least 8 characters';
    }
    
    if (!passwordData.confirmPassword) {
      errors.confirmPassword = 'Please confirm your password';
    } else if (passwordData.newPassword !== passwordData.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }
    
    setPasswordErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  // Handle change password
  const handleChangePassword = () => {
    if (!validatePasswordChange()) return;
    
    // In a real app, this would call an API
    toast.success('Password changed successfully');
    
    // Reset form
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    });
  };
  
  // Handle save profile
  const handleSaveProfile = () => {
    if (!profileData.name || !profileData.email) {
      toast.error('Name and email are required');
      return;
    }
    
    // In a real app, this would call an API
    toast.success('Profile updated successfully');
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-neutral-900">Settings</h1>
        <p className="text-neutral-500">
          Manage your account and preferences
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <Card className="border border-neutral-200">
            <div className="flex flex-col items-center mb-6">
              <div className="w-24 h-24 rounded-full overflow-hidden bg-neutral-200 mb-4">
                {currentUser?.avatarUrl ? (
                  <img 
                    src={currentUser.avatarUrl} 
                    alt={currentUser.name} 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-primary-100 text-primary-600">
                    <User size={32} />
                  </div>
                )}
              </div>
              <h3 className="text-xl font-semibold">{currentUser?.name}</h3>
              <p className="text-neutral-500">{currentUser?.role}</p>
            </div>
            
            <nav>
              <a 
                href="#profile" 
                className="block px-4 py-2 rounded-lg hover:bg-neutral-100 transition-colors mb-1"
              >
                Profile Settings
              </a>
              <a 
                href="#security" 
                className="block px-4 py-2 rounded-lg hover:bg-neutral-100 transition-colors mb-1"
              >
                Security
              </a>
            </nav>
          </Card>
        </div>
        
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Profile Settings */}
          <Card id="profile" className="border border-neutral-200">
            <h2 className="text-xl font-semibold mb-6">Profile Settings</h2>
            
            <div className="space-y-4">
              <Input
                label="Full Name"
                name="name"
                value={profileData.name}
                onChange={handleProfileChange}
                placeholder="Enter your full name"
              />
              
              <Input
                label="Email"
                name="email"
                type="email"
                value={profileData.email}
                onChange={handleProfileChange}
                placeholder="Enter your email"
              />
              
              <Input
                label="Mobile Number"
                name="mobile"
                value={profileData.mobile}
                onChange={handleProfileChange}
                placeholder="Enter your mobile number"
              />
              
              <div className="pt-4">
                <Button 
                  onClick={handleSaveProfile}
                  leftIcon={<Save size={16} />}
                >
                  Save Changes
                </Button>
              </div>
            </div>
          </Card>
          
          {/* Security */}
          <Card id="security" className="border border-neutral-200">
            <h2 className="text-xl font-semibold mb-6">Change Password</h2>
            
            <div className="space-y-4">
              <Input
                label="Current Password"
                name="currentPassword"
                type="password"
                value={passwordData.currentPassword}
                onChange={handlePasswordChange}
                placeholder="Enter your current password"
                error={passwordErrors.currentPassword}
              />
              
              <Input
                label="New Password"
                name="newPassword"
                type="password"
                value={passwordData.newPassword}
                onChange={handlePasswordChange}
                placeholder="Enter your new password"
                error={passwordErrors.newPassword}
              />
              
              <Input
                label="Confirm New Password"
                name="confirmPassword"
                type="password"
                value={passwordData.confirmPassword}
                onChange={handlePasswordChange}
                placeholder="Confirm your new password"
                error={passwordErrors.confirmPassword}
              />
              
              <div className="pt-4">
                <Button 
                  onClick={handleChangePassword}
                  leftIcon={<Lock size={16} />}
                >
                  Change Password
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;