import React, { useState } from 'react';
import { Plus, Search, Edit, Trash, X, User } from 'lucide-react';
import { demoStaffMembers } from '../../data/demoData';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Badge from '../../components/ui/Badge';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

const StaffPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [roleFilter, setRoleFilter] = useState<'all' | 'admin' | 'staff'>('all');
  
  // Filter staff based on search and filters
  const filteredStaff = demoStaffMembers.filter(staff => {
    const matchesSearch = 
      staff.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      staff.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      staff.mobile.includes(searchTerm);
    
    const matchesStatus = statusFilter === 'all' || staff.status === statusFilter;
    const matchesRole = roleFilter === 'all' || staff.role === roleFilter;
    
    return matchesSearch && matchesStatus && matchesRole;
  });
  
  // Format date
  const formatDate = (dateStr: string) => {
    return format(new Date(dateStr), 'MMM d, yyyy');
  };
  
  // Add staff dialog
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newStaff, setNewStaff] = useState({
    name: '',
    email: '',
    mobile: '',
    role: 'staff' as 'admin' | 'staff',
    status: 'active' as 'active' | 'inactive',
    sendWelcome: true,
  });
  
  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setNewStaff(prev => ({ ...prev, [name]: checked }));
    } else {
      setNewStaff(prev => ({ ...prev, [name]: value }));
    }
  };
  
  // Add staff function
  const handleAddStaff = () => {
    if (!newStaff.name || !newStaff.email || !newStaff.mobile) {
      toast.error('Please fill all required fields');
      return;
    }
    
    toast.success(`Staff ${newStaff.name} added successfully`);
    setShowAddDialog(false);
    setNewStaff({
      name: '',
      email: '',
      mobile: '',
      role: 'staff',
      status: 'active',
      sendWelcome: true,
    });
  };
  
  return (
    <div className="animate-fade-in">
      <div className="flex flex-wrap justify-between items-start gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900">Staff Management</h1>
          <p className="text-neutral-500">
            Manage staff accounts and access
          </p>
        </div>
        <Button 
          leftIcon={<Plus size={18} />}
          onClick={() => setShowAddDialog(true)}
        >
          Add Staff
        </Button>
      </div>
      
      {/* Add Staff Dialog */}
      {showAddDialog && (
        <div className="fixed inset-0 bg-neutral-900 bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-elevated max-w-lg w-full animate-fade-in animate-slide-in">
            <div className="flex justify-between items-center p-6 border-b border-neutral-200">
              <h3 className="text-xl font-semibold">Add New Staff</h3>
              <button 
                onClick={() => setShowAddDialog(false)}
                className="text-neutral-500 hover:text-neutral-700"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="p-6">
              <div className="space-y-4">
                <Input
                  label="Full Name"
                  name="name"
                  value={newStaff.name}
                  onChange={handleInputChange}
                  placeholder="Enter full name"
                  required
                />
                
                <Input
                  label="Email"
                  name="email"
                  type="email"
                  value={newStaff.email}
                  onChange={handleInputChange}
                  placeholder="Enter email address"
                  required
                />
                
                <Input
                  label="Mobile"
                  name="mobile"
                  value={newStaff.mobile}
                  onChange={handleInputChange}
                  placeholder="Enter mobile number"
                  required
                />
                
                <div>
                  <label className="form-label">Role</label>
                  <select
                    name="role"
                    value={newStaff.role}
                    onChange={handleInputChange}
                    className="input-field"
                  >
                    <option value="admin">Admin</option>
                    <option value="staff">Staff</option>
                  </select>
                </div>
                
                <div>
                  <label className="form-label">Status</label>
                  <select
                    name="status"
                    value={newStaff.status}
                    onChange={handleInputChange}
                    className="input-field"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
                
                <div className="flex items-center">
                  <input
                    id="sendWelcome"
                    name="sendWelcome"
                    type="checkbox"
                    checked={newStaff.sendWelcome}
                    onChange={handleInputChange}
                    className="h-4 w-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
                  />
                  <label htmlFor="sendWelcome" className="ml-2 block text-sm text-neutral-600">
                    Send welcome email/SMS
                  </label>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end gap-3 p-6 border-t border-neutral-200">
              <Button 
                variant="outline"
                onClick={() => setShowAddDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                onClick={handleAddStaff}
                leftIcon={<User size={16} />}
              >
                Add Staff
              </Button>
            </div>
          </div>
        </div>
      )}
      
      <Card className="mb-6 border border-neutral-200">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[220px]">
            <Input
              placeholder="Search by name, email, or mobile"
              leftIcon={<Search size={16} />}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value as 'all' | 'admin' | 'staff')}
              className="input-field"
            >
              <option value="all">All Roles</option>
              <option value="admin">Admin</option>
              <option value="staff">Staff</option>
            </select>
          </div>
          
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as 'all' | 'active' | 'inactive')}
              className="input-field"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </Card>
      
      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Mobile</th>
              <th>Role</th>
              <th>Status</th>
              <th>Created</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredStaff.length === 0 ? (
              <tr>
                <td colSpan={7} className="text-center py-8">
                  <p className="text-neutral-500">No staff members found</p>
                </td>
              </tr>
            ) : (
              filteredStaff.map((staff) => (
                <tr key={staff.id}>
                  <td className="font-medium">{staff.name}</td>
                  <td>{staff.email}</td>
                  <td>{staff.mobile}</td>
                  <td>
                    <Badge 
                      variant={staff.role === 'admin' ? 'accent' : 'neutral'}
                    >
                      {staff.role === 'admin' ? 'Admin' : 'Staff'}
                    </Badge>
                  </td>
                  <td>
                    <Badge 
                      variant={staff.status === 'active' ? 'success' : 'error'}
                    >
                      {staff.status === 'active' ? 'Active' : 'Inactive'}
                    </Badge>
                  </td>
                  <td>{formatDate(staff.createdAt)}</td>
                  <td>
                    <div className="flex space-x-2">
                      <button 
                        className="p-1.5 text-neutral-600 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                        onClick={() => toast.success('Edit feature coming soon!')}
                      >
                        <Edit size={16} />
                      </button>
                      <button 
                        className="p-1.5 text-neutral-600 hover:text-error-600 hover:bg-error-50 rounded-lg transition-colors"
                        onClick={() => toast.error('Delete operation not allowed!')}
                      >
                        <Trash size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StaffPage;