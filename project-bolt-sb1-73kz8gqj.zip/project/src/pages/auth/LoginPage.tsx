import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import toast from 'react-hot-toast';

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [errors, setErrors] = useState<{email?: string; password?: string}>({});
  
  const { login, isLoading } = useAuth();
  const navigate = useNavigate();
  
  const validateForm = () => {
    const newErrors: {email?: string; password?: string} = {};
    let isValid = true;
    
    if (!email) {
      newErrors.email = 'Email is required';
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Invalid email format';
      isValid = false;
    }
    
    if (!password) {
      newErrors.password = 'Password is required';
      isValid = false;
    }
    
    setErrors(newErrors);
    return isValid;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    try {
      const user = await login(email, password);
      
      toast.success(`Welcome back, ${user.name}!`);
      
      // Navigate based on role
      if (user.role === 'admin') {
        navigate('/dashboard');
      } else {
        navigate('/billing');
      }
    } catch (error) {
      toast.error('Invalid email or password');
    }
  };
  
  return (
    <div>
      <h2 className="text-xl font-bold text-center text-neutral-900 mb-6">Sign in to your account</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <Input
          id="email"
          type="email"
          label="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="e.g. you@example.com"
          error={errors.email}
          leftIcon={<Mail size={16} />}
          autoComplete="email"
          required
        />
        
        <Input
          id="password"
          type="password"
          label="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Enter your password"
          error={errors.password}
          leftIcon={<Lock size={16} />}
          autoComplete="current-password"
          required
        />
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <input
              id="remember-me"
              name="remember-me"
              type="checkbox"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="h-4 w-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
            />
            <label htmlFor="remember-me" className="ml-2 block text-sm text-neutral-600">
              Remember me
            </label>
          </div>
          
          <div className="text-sm">
            <a href="#" className="font-medium text-primary-600 hover:text-primary-500">
              Forgot your password?
            </a>
          </div>
        </div>
        
        <div>
          <Button 
            type="submit" 
            isLoading={isLoading} 
            className="w-full"
          >
            Sign in
          </Button>
        </div>
      </form>
      
      <div className="mt-6">
        <p className="text-xs text-neutral-500 text-center">
          Demo Credentials:
        </p>
        <p className="text-xs text-neutral-500 text-center">
          Admin: admin@sareeshop.com | Staff: staff@sareeshop.com
        </p>
        <p className="text-xs text-neutral-500 text-center">
          Password: password
        </p>
      </div>
    </div>
  );
};

export default LoginPage;