import React, { useState } from 'react';
import { Search, Plus, Edit, Trash, AlertTriangle } from 'lucide-react';
import { demoSareeItems } from '../../data/demoData';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Badge from '../../components/ui/Badge';
import AddStockModal from '../../components/stock/AddStockModal';
import toast from 'react-hot-toast';

const StockPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showLowStock, setShowLowStock] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState<typeof demoSareeItems[0] | null>(null);
  
  // Filter sarees based on search and filter
  const filteredSarees = demoSareeItems.filter(saree => {
    const matchesSearch = saree.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         saree.sku.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesLowStock = !showLowStock || saree.quantity <= 5;
    
    return matchesSearch && matchesLowStock;
  });
  
  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const handleEdit = (item: typeof demoSareeItems[0]) => {
    setEditingItem(item);
  };
  
  return (
    <div className="animate-fade-in">
      <div className="flex flex-wrap justify-between items-start gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900">Stock Management</h1>
          <p className="text-neutral-500">
            Manage your saree inventory
          </p>
        </div>
        <Button 
          leftIcon={<Plus size={18} />}
          onClick={() => setShowAddModal(true)}
        >
          Add New Stock
        </Button>
      </div>
      
      {/* Add/Edit Stock Modal */}
      {(showAddModal || editingItem) && (
        <AddStockModal
          onClose={() => {
            setShowAddModal(false);
            setEditingItem(null);
          }}
          initialData={editingItem || undefined}
          isEdit={!!editingItem}
        />
      )}
      
      <Card className="mb-6 border border-neutral-200">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[300px]">
            <Input
              placeholder="Search by name or SKU"
              leftIcon={<Search size={16} />}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex items-center">
            <label className="inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                className="sr-only peer"
                checked={showLowStock}
                onChange={() => setShowLowStock(!showLowStock)}
              />
              <div className="relative w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
              <span className="ml-3 text-sm font-medium text-neutral-700">Show Low Stock Only</span>
            </label>
          </div>
        </div>
      </Card>
      
      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Image</th>
              <th>Saree</th>
              <th>SKU/Code</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredSarees.length === 0 ? (
              <tr>
                <td colSpan={6} className="text-center py-8">
                  <p className="text-neutral-500">No sarees found</p>
                </td>
              </tr>
            ) : (
              filteredSarees.map((saree) => (
                <tr key={saree.id}>
                  <td className="w-20">
                    {saree.imageUrl ? (
                      <div className="w-16 h-16 rounded-lg overflow-hidden bg-neutral-100">
                        <img 
                          src={saree.imageUrl} 
                          alt={saree.name} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="w-16 h-16 rounded-lg bg-neutral-100 flex items-center justify-center">
                        <span className="text-neutral-400 text-xs">No image</span>
                      </div>
                    )}
                  </td>
                  <td>
                    <div className="font-medium">{saree.name}</div>
                    {saree.description && (
                      <div className="text-xs text-neutral-500 mt-1 line-clamp-1">
                        {saree.description}
                      </div>
                    )}
                  </td>
                  <td>{saree.sku}</td>
                  <td className="font-medium">{formatCurrency(saree.price)}</td>
                  <td>
                    <div className="flex items-center">
                      {saree.quantity <= 5 ? (
                        <>
                          <AlertTriangle size={16} className="text-warning-500 mr-2" />
                          <Badge variant="warning">{saree.quantity} left</Badge>
                        </>
                      ) : (
                        <span>{saree.quantity}</span>
                      )}
                    </div>
                  </td>
                  <td>
                    <div className="flex space-x-2">
                      <button 
                        className="p-1.5 text-neutral-600 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                        onClick={() => handleEdit(saree)}
                      >
                        <Edit size={16} />
                      </button>
                      <button 
                        className="p-1.5 text-neutral-600 hover:text-error-600 hover:bg-error-50 rounded-lg transition-colors"
                        onClick={() => toast.error('Delete operation not allowed!')}
                      >
                        <Trash size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StockPage;