import React, { useState } from 'react';
import { 
  ChevronDown, 
  ChevronUp, 
  Package, 
  Plus, 
  Printer, 
  QrCode, 
  Search, 
  Send, 
  Trash, 
  User, 
  X 
} from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import BillPreview from '../../components/billing/BillPreview';
import { demoSareeItems } from '../../data/demoData';
import { BillItem, Customer, Bill } from '../../types';
import toast from 'react-hot-toast';

const BillingPage: React.FC = () => {
  // Customer state
  const [customerPanelOpen, setCustomerPanelOpen] = useState(true);
  const [customer, setCustomer] = useState<Customer>({
    name: '',
    contact: '',
    email: '',
    whatsapp: '',
  });
  
  // Bill items state
  const [billItems, setBillItems] = useState<BillItem[]>([]);
  const [qrInput, setQrInput] = useState('');
  const [selectedSaree, setSelectedSaree] = useState('');
  const [quantity, setQuantity] = useState(1);
  
  // Bill preview state
  const [showPreview, setShowPreview] = useState(false);
  
  // Calculation
  const subtotal = billItems.reduce((sum, item) => sum + item.subtotal, 0);
  const gstRate = 0.05; // 5% GST
  const gstAmount = subtotal * gstRate;
  const total = subtotal + gstAmount;
  
  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };
  
  // Handle customer input change
  const handleCustomerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCustomer(prev => ({ ...prev, [name]: value }));
  };
  
  // Handle QR code scanning/input
  const handleQrScan = (e: React.FormEvent) => {
    e.preventDefault();
    
    const sareeItem = demoSareeItems.find(item => item.sku === qrInput);
    
    if (sareeItem) {
      addItemToBill(sareeItem.id, sareeItem.name, sareeItem.price, 1);
      setQrInput('');
      toast.success(`Added ${sareeItem.name} to bill`);
    } else {
      toast.error('Invalid QR code');
    }
  };
  
  // Handle manual item addition
  const handleAddManualItem = () => {
    if (!selectedSaree || quantity < 1) {
      toast.error('Please select a saree and valid quantity');
      return;
    }
    
    const sareeItem = demoSareeItems.find(item => item.id === selectedSaree);
    
    if (sareeItem) {
      addItemToBill(sareeItem.id, sareeItem.name, sareeItem.price, quantity);
      setSelectedSaree('');
      setQuantity(1);
      toast.success(`Added ${sareeItem.name} to bill`);
    }
  };
  
  // Add item to bill
  const addItemToBill = (sareeId: string, name: string, price: number, qty: number) => {
    const existingItemIndex = billItems.findIndex(item => item.sareeId === sareeId);
    
    if (existingItemIndex >= 0) {
      const updatedItems = [...billItems];
      updatedItems[existingItemIndex].quantity += qty;
      updatedItems[existingItemIndex].subtotal = updatedItems[existingItemIndex].quantity * price;
      setBillItems(updatedItems);
    } else {
      const newItem: BillItem = {
        id: `item-${Date.now()}`,
        sareeId,
        name,
        price,
        quantity: qty,
        subtotal: price * qty,
      };
      
      setBillItems(prev => [...prev, newItem]);
    }
  };
  
  // Remove item from bill
  const removeItem = (id: string) => {
    setBillItems(prev => prev.filter(item => item.id !== id));
  };
  
  // Generate bill object for preview
  const generateBill = (): Bill => ({
    id: `BILL-${Date.now()}`,
    billNumber: `INV-${Date.now()}`,
    customer,
    items: billItems,
    subtotal,
    gstAmount,
    total,
    createdBy: 'Demo User',
    createdAt: new Date().toISOString(),
  });
  
  // Handle bill actions
  const handleSaveAndPrint = () => {
    if (billItems.length === 0) {
      toast.error('Please add at least one item to the bill');
      return;
    }
    
    if (!customer.name || !customer.contact) {
      toast.error('Please enter customer name and contact');
      return;
    }
    
    setShowPreview(true);
  };
  
  const handlePrint = () => {
    toast.success('Bill sent to printer');
    setShowPreview(false);
    // Reset form after successful print
    setBillItems([]);
    setCustomer({
      name: '',
      contact: '',
      email: '',
      whatsapp: '',
    });
  };
  
  const handleSend = () => {
    toast.success('Bill sent to customer');
    setShowPreview(false);
    // Reset form after successful send
    setBillItems([]);
    setCustomer({
      name: '',
      contact: '',
      email: '',
      whatsapp: '',
    });
  };
  
  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900">Create Bill</h1>
          <p className="text-neutral-500">
            Create a new bill for your customer
          </p>
        </div>
      </div>
      
      {/* Bill Preview Modal */}
      {showPreview && (
        <BillPreview
          bill={generateBill()}
          onClose={() => setShowPreview(false)}
          onPrint={handlePrint}
          onSend={handleSend}
        />
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content (Customer & Items) */}
        <div className="lg:col-span-2 space-y-6">
          {/* Customer Details */}
          <Card className="border border-neutral-200">
            <div 
              className="flex justify-between items-center cursor-pointer"
              onClick={() => setCustomerPanelOpen(!customerPanelOpen)}
            >
              <div className="flex items-center">
                <User size={20} className="mr-2 text-neutral-500" />
                <h3 className="text-lg font-semibold">Customer Details</h3>
              </div>
              <button className="text-neutral-500">
                {customerPanelOpen ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
              </button>
            </div>
            
            {customerPanelOpen && (
              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Customer Name"
                  name="name"
                  value={customer.name}
                  onChange={handleCustomerChange}
                  placeholder="Enter customer name"
                />
                
                <Input
                  label="Contact Number"
                  name="contact"
                  value={customer.contact}
                  onChange={handleCustomerChange}
                  placeholder="Enter contact number"
                />
                
                <Input
                  label="Email (Optional)"
                  name="email"
                  type="email"
                  value={customer.email}
                  onChange={handleCustomerChange}
                  placeholder="Enter email address"
                />
                
                <Input
                  label="WhatsApp Number (Optional)"
                  name="whatsapp"
                  value={customer.whatsapp}
                  onChange={handleCustomerChange}
                  placeholder="Enter WhatsApp number"
                />
              </div>
            )}
          </Card>
          
          {/* Item Entry */}
          <Card className="border border-neutral-200">
            <h3 className="text-lg font-semibold mb-4">Item Entry</h3>
            
            {/* QR Scan */}
            <div className="mb-6">
              <form onSubmit={handleQrScan}>
                <div className="flex">
                  <div className="flex-1 mr-2">
                    <Input
                      label="Scan QR Code"
                      value={qrInput}
                      onChange={(e) => setQrInput(e.target.value)}
                      placeholder="Scan or enter product code"
                      leftIcon={<QrCode size={16} />}
                      autoFocus
                    />
                  </div>
                  <div className="self-end">
                    <Button type="submit" leftIcon={<Search size={16} />}>
                      Find
                    </Button>
                  </div>
                </div>
              </form>
            </div>
            
            {/* Manual Entry */}
            <div className="p-4 bg-neutral-50 rounded-lg mb-6">
              <h4 className="text-sm font-medium mb-3">Manual Entry</h4>
              <div className="flex flex-wrap gap-3">
                <div className="flex-1 min-w-[200px]">
                  <select
                    value={selectedSaree}
                    onChange={(e) => setSelectedSaree(e.target.value)}
                    className="input-field"
                  >
                    <option value="">Select Saree</option>
                    {demoSareeItems.map(saree => (
                      <option key={saree.id} value={saree.id}>
                        {saree.name} - {formatCurrency(saree.price)}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="w-20">
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                    className="input-field"
                  />
                </div>
                
                <div>
                  <Button 
                    variant="secondary" 
                    leftIcon={<Plus size={16} />}
                    onClick={handleAddManualItem}
                  >
                    Add
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Items List */}
            <div className="overflow-x-auto">
              <table className="w-full min-w-full table-auto">
                <thead className="text-xs text-left text-neutral-500 uppercase tracking-wider">
                  <tr>
                    <th className="px-4 py-2">Item</th>
                    <th className="px-4 py-2 text-right">Price</th>
                    <th className="px-4 py-2 text-center">Qty</th>
                    <th className="px-4 py-2 text-right">Subtotal</th>
                    <th className="px-4 py-2 w-10"></th>
                  </tr>
                </thead>
                <tbody>
                  {billItems.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-4 py-6 text-center text-neutral-500">
                        <div className="flex flex-col items-center justify-center">
                          <Package size={24} className="mb-2 opacity-50" />
                          <p>No items added</p>
                          <p className="text-xs">Scan a QR code or add items manually</p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    billItems.map((item) => (
                      <tr key={item.id} className="hover:bg-neutral-50">
                        <td className="px-4 py-3 border-t border-neutral-100">
                          <div className="text-sm font-medium">{item.name}</div>
                        </td>
                        <td className="px-4 py-3 text-right border-t border-neutral-100">
                          {formatCurrency(item.price)}
                        </td>
                        <td className="px-4 py-3 text-center border-t border-neutral-100">
                          {item.quantity}
                        </td>
                        <td className="px-4 py-3 text-right border-t border-neutral-100 font-medium">
                          {formatCurrency(item.subtotal)}
                        </td>
                        <td className="px-4 py-3 text-center border-t border-neutral-100">
                          <button 
                            onClick={() => removeItem(item.id)}
                            className="text-error-500 hover:text-error-700 transition-colors"
                          >
                            <X size={16} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
        
        {/* Bill Summary (Sticky) */}
        <div className="lg:col-span-1">
          <div className="lg:sticky lg:top-24">
            <Card className="border border-neutral-200">
              <h3 className="text-lg font-semibold mb-4">Bill Summary</h3>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between">
                  <span className="text-neutral-600">Subtotal</span>
                  <span className="font-medium">{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">GST (5%)</span>
                  <span className="font-medium">{formatCurrency(gstAmount)}</span>
                </div>
                <div className="pt-3 border-t border-neutral-200 flex justify-between">
                  <span className="text-lg font-semibold">Total</span>
                  <span className="text-lg font-bold text-primary-700">{formatCurrency(total)}</span>
                </div>
              </div>
              
              <div className="space-y-3">
                <Button 
                  className="w-full"
                  leftIcon={<Printer size={16} />}
                  onClick={handleSaveAndPrint}
                >
                  Save & Print
                </Button>
                
                <Button 
                  variant="outline"
                  className="w-full"
                  leftIcon={<Send size={16} />}
                  onClick={() => setShowPreview(true)}
                >
                  Preview Bill
                </Button>
                
                <Button 
                  variant="ghost"
                  className="w-full"
                  leftIcon={<Trash size={16} />}
                  onClick={() => {
                    setBillItems([]);
                    setCustomer({
                      name: '',
                      contact: '',
                      email: '',
                      whatsapp: '',
                    });
                    toast.success('Bill cleared');
                  }}
                >
                  Clear Bill
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BillingPage;