import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowUpRight, 
  Package, 
  QrCode, 
  Receipt, 
  TrendingUp, 
  Wallet, 
  Receipt as ReceiptIcon,
  Package as PackageIcon,
  UserPlus,
} from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { demoSalesSummary, demoRecentActivities } from '../../data/demoData';
import { format } from 'date-fns';

// Helper to format currency
const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
};

// Helper to format date and time
const formatDateTime = (dateStr: string) => {
  const date = new Date(dateStr);
  return format(date, 'MMM d, yyyy • h:mm a');
};

const DashboardPage: React.FC = () => {
  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900">Dashboard</h1>
          <p className="text-neutral-500">
            Welcome back, view today's statistics and recent activity
          </p>
        </div>
        <div className="flex space-x-3">
          <Button 
            variant="outline"
            size="lg"
            leftIcon={<Package size={18} />}
            onClick={() => {}}
          >
            Add Stock
          </Button>
          <Button 
            variant="primary"
            size="lg"
            leftIcon={<Receipt size={18} />}
            onClick={() => {}}
          >
            Create Bill
          </Button>
        </div>
      </div>

      {/* Sales Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="border border-neutral-200">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-neutral-500 text-sm">Today's Sales</p>
              <h3 className="text-2xl font-bold mt-1 text-neutral-900">
                {formatCurrency(demoSalesSummary.todayTotal)}
              </h3>
            </div>
            <div className="p-3 bg-primary-100 rounded-full">
              <Wallet size={20} className="text-primary-600" />
            </div>
          </div>
        </Card>

        <Card className="border border-neutral-200">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-neutral-500 text-sm">Bills Generated</p>
              <h3 className="text-2xl font-bold mt-1 text-neutral-900">
                {demoSalesSummary.todayBills}
              </h3>
            </div>
            <div className="p-3 bg-secondary-100 rounded-full">
              <Receipt size={20} className="text-secondary-600" />
            </div>
          </div>
        </Card>

        <Card className="border border-neutral-200">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-neutral-500 text-sm">GST Collected</p>
              <h3 className="text-2xl font-bold mt-1 text-neutral-900">
                {formatCurrency(demoSalesSummary.todayGst)}
              </h3>
            </div>
            <div className="p-3 bg-accent-100 rounded-full">
              <TrendingUp size={20} className="text-accent-700" />
            </div>
          </div>
        </Card>

        <Card className="border border-neutral-200">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-neutral-500 text-sm">This Week</p>
              <h3 className="text-2xl font-bold mt-1 text-neutral-900">
                {formatCurrency(demoSalesSummary.weekTotal)}
              </h3>
            </div>
            <div className="p-3 bg-success-100 rounded-full">
              <ArrowUpRight size={20} className="text-success-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Quick Actions & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Actions */}
        <Card className="border border-neutral-200 lg:col-span-1">
          <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
          <div className="space-y-3">
            <Link 
              to="/stock" 
              className="flex items-center p-3 bg-neutral-50 hover:bg-neutral-100 rounded-lg transition-colors"
            >
              <div className="p-2 bg-primary-100 rounded-full mr-3">
                <PackageIcon size={18} className="text-primary-600" />
              </div>
              <div>
                <p className="font-medium">Add New Stock</p>
                <p className="text-xs text-neutral-500">Add sarees to inventory</p>
              </div>
            </Link>
            
            <Link 
              to="/qrcodes" 
              className="flex items-center p-3 bg-neutral-50 hover:bg-neutral-100 rounded-lg transition-colors"
            >
              <div className="p-2 bg-secondary-100 rounded-full mr-3">
                <QrCode size={18} className="text-secondary-600" />
              </div>
              <div>
                <p className="font-medium">Generate QR Code</p>
                <p className="text-xs text-neutral-500">Create QR code for a saree</p>
              </div>
            </Link>
            
            <Link 
              to="/billing" 
              className="flex items-center p-3 bg-neutral-50 hover:bg-neutral-100 rounded-lg transition-colors"
            >
              <div className="p-2 bg-accent-100 rounded-full mr-3">
                <ReceiptIcon size={18} className="text-accent-700" />
              </div>
              <div>
                <p className="font-medium">Create New Bill</p>
                <p className="text-xs text-neutral-500">Generate a bill for customer</p>
              </div>
            </Link>
            
            <Link 
              to="/staff" 
              className="flex items-center p-3 bg-neutral-50 hover:bg-neutral-100 rounded-lg transition-colors"
            >
              <div className="p-2 bg-success-100 rounded-full mr-3">
                <UserPlus size={18} className="text-success-600" />
              </div>
              <div>
                <p className="font-medium">Add Staff Member</p>
                <p className="text-xs text-neutral-500">Create a new staff account</p>
              </div>
            </Link>
          </div>
        </Card>

        {/* Recent Activity */}
        <Card className="border border-neutral-200 lg:col-span-2">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Recent Activity</h2>
            <Button variant="ghost" size="sm">View All</Button>
          </div>
          
          <div className="space-y-4">
            {demoRecentActivities.slice(0, 5).map((activity) => (
              <div 
                key={activity.id} 
                className="flex items-start p-3 border-b border-neutral-100 last:border-0"
              >
                <div className="flex-shrink-0">
                  {activity.type === 'bill' && (
                    <div className="p-2 bg-accent-100 rounded-full">
                      <Receipt size={16} className="text-accent-700" />
                    </div>
                  )}
                  {activity.type === 'stock' && (
                    <div className="p-2 bg-primary-100 rounded-full">
                      <Package size={16} className="text-primary-600" />
                    </div>
                  )}
                  {activity.type === 'staff' && (
                    <div className="p-2 bg-secondary-100 rounded-full">
                      <UserPlus size={16} className="text-secondary-600" />
                    </div>
                  )}
                </div>
                
                <div className="ml-3 flex-1">
                  <p className="text-sm font-medium">{activity.details}</p>
                  <div className="flex justify-between items-center mt-1">
                    <span className="text-xs text-neutral-500">
                      By {activity.user}
                    </span>
                    <span className="text-xs text-neutral-500">
                      {formatDateTime(activity.timestamp)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default DashboardPage;