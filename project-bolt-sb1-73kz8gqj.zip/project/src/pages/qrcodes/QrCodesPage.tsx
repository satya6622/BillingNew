import React, { useState } from 'react';
import { Plus, Download, Trash, Search, QrCode, RefreshCw as Refresh, Printer } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import { demoQrCodes, demoSareeItems } from '../../data/demoData';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

const QrCodesPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  // Filter QR codes based on search
  const filteredQrCodes = demoQrCodes.filter(qr => 
    qr.sareeName.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };
  
  // Format date
  const formatDate = (dateStr: string) => {
    return format(new Date(dateStr), 'MMM d, yyyy');
  };
  
  // Generate new QR code dialog
  const [showGenerateDialog, setShowGenerateDialog] = useState(false);
  const [selectedSaree, setSelectedSaree] = useState('');
  const [generateQty, setGenerateQty] = useState(1);
  
  // Selected saree details
  const sareeDetails = demoSareeItems.find(s => s.id === selectedSaree);
  
  // Generate QR code function
  const handleGenerateQr = () => {
    if (!selectedSaree) {
      toast.error('Please select a saree');
      return;
    }
    
    toast.success(`QR code generated for ${sareeDetails?.name}`);
    setShowGenerateDialog(false);
    setSelectedSaree('');
    setGenerateQty(1);
  };
  
  return (
    <div className="animate-fade-in">
      <div className="flex flex-wrap justify-between items-start gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900">QR Code Management</h1>
          <p className="text-neutral-500">
            Generate and manage QR codes for your sarees
          </p>
        </div>
        <Button 
          leftIcon={<Plus size={18} />}
          onClick={() => setShowGenerateDialog(true)}
        >
          Generate New QR
        </Button>
      </div>
      
      {/* Generate QR Dialog */}
      {showGenerateDialog && (
        <div className="fixed inset-0 bg-neutral-900 bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-elevated max-w-2xl w-full animate-fade-in animate-slide-in">
            <div className="flex justify-between items-center p-6 border-b border-neutral-200">
              <h3 className="text-xl font-semibold">Generate QR Code</h3>
              <button 
                onClick={() => setShowGenerateDialog(false)}
                className="text-neutral-500 hover:text-neutral-700"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="mb-4">
                    <label className="form-label">Select Saree</label>
                    <select
                      value={selectedSaree}
                      onChange={(e) => setSelectedSaree(e.target.value)}
                      className="input-field"
                    >
                      <option value="">Select a saree</option>
                      {demoSareeItems.map(saree => (
                        <option key={saree.id} value={saree.id}>
                          {saree.name} - {saree.sku}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="mb-4">
                    <label className="form-label">Price</label>
                    <input
                      type="text"
                      className="input-field"
                      value={sareeDetails ? formatCurrency(sareeDetails.price) : ''}
                      disabled
                    />
                  </div>
                  
                  <div className="mb-4">
                    <label className="form-label">Quantity</label>
                    <input
                      type="number"
                      min="1"
                      className="input-field"
                      value={generateQty}
                      onChange={(e) => setGenerateQty(parseInt(e.target.value) || 1)}
                    />
                  </div>
                </div>
                
                <div className="flex flex-col items-center justify-center">
                  {selectedSaree ? (
                    <div className="text-center">
                      <div className="bg-white p-3 border border-neutral-200 rounded-lg inline-block mb-3">
                        <img 
                          src={sareeDetails?.qrCodeUrl || 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=demo'} 
                          alt="QR Code Preview" 
                          className="w-40 h-40"
                        />
                      </div>
                      <p className="text-sm text-neutral-500">QR Code Preview</p>
                    </div>
                  ) : (
                    <div className="bg-neutral-100 rounded-lg w-48 h-48 flex items-center justify-center">
                      <QrCode size={48} className="text-neutral-300" />
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex justify-end gap-3 p-6 border-t border-neutral-200">
              <Button 
                variant="outline"
                onClick={() => setShowGenerateDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                onClick={handleGenerateQr}
                leftIcon={<QrCode size={16} />}
              >
                Generate QR Code
              </Button>
            </div>
          </div>
        </div>
      )}
      
      <Card className="mb-6 border border-neutral-200">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[300px]">
            <Input
              placeholder="Search by saree name"
              leftIcon={<Search size={16} />}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </Card>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredQrCodes.length === 0 ? (
          <div className="col-span-full text-center py-8">
            <QrCode size={48} className="text-neutral-300 mx-auto mb-2" />
            <p className="text-neutral-500">No QR codes found</p>
          </div>
        ) : (
          filteredQrCodes.map((qr) => (
            <Card key={qr.id} className="border border-neutral-200">
              <div className="flex flex-col items-center mb-4">
                <div className="bg-white p-3 border border-neutral-200 rounded-lg mb-3">
                  <img 
                    src={qr.imageUrl} 
                    alt={qr.sareeName} 
                    className="w-32 h-32"
                  />
                </div>
                <h3 className="text-center font-medium text-base truncate max-w-full">
                  {qr.sareeName}
                </h3>
                <p className="text-center text-neutral-500 text-sm">
                  {formatCurrency(qr.price)}
                </p>
              </div>
              
              <div className="text-xs text-neutral-500 text-center mb-4">
                Generated on {formatDate(qr.generatedAt)}
              </div>
              
              <div className="flex justify-center space-x-2">
                <button 
                  className="p-2 text-neutral-600 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                  onClick={() => toast.success('Download feature coming soon!')}
                >
                  <Download size={16} />
                </button>
                <button 
                  className="p-2 text-neutral-600 hover:text-secondary-600 hover:bg-secondary-50 rounded-lg transition-colors"
                  onClick={() => toast.success('Print feature coming soon!')}
                >
                  <Printer size={16} />
                </button>
                <button 
                  className="p-2 text-neutral-600 hover:text-accent-600 hover:bg-accent-50 rounded-lg transition-colors"
                  onClick={() => toast.success('Regenerate feature coming soon!')}
                >
                  <Refresh size={16} />
                </button>
                <button 
                  className="p-2 text-neutral-600 hover:text-error-600 hover:bg-error-50 rounded-lg transition-colors"
                  onClick={() => toast.error('Delete operation not allowed!')}
                >
                  <Trash size={16} />
                </button>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default QrCodesPage;