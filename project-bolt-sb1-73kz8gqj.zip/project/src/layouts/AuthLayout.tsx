import React from 'react';
import { Outlet } from 'react-router-dom';
import { Layers } from 'lucide-react';

const AuthLayout: React.FC = () => {
  return (
    <div className="min-h-screen flex bg-primary-900">
      <div className="flex-1 flex flex-col justify-center px-4 py-12 sm:px-6 lg:px-20 xl:px-24">
        <div className="mx-auto w-full max-w-sm lg:max-w-md">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-3">
              <div className="bg-white p-3 rounded-2xl shadow-elevated">
                <Layers size={32} className="text-primary-600" />
              </div>
            </div>
            <h2 className="text-3xl font-bold text-white">Saree Shop</h2>
            <p className="mt-2 text-sm text-primary-200">Premium Billing System</p>
          </div>
          
          <div className="bg-white py-8 px-4 shadow-elevated sm:rounded-2xl sm:px-10">
            <Outlet />
          </div>
        </div>
      </div>
      
      <div className="hidden lg:block relative w-0 flex-1">
        <img
          className="absolute inset-0 h-full w-full object-cover"
          src="https://images.pexels.com/photos/2235071/pexels-photo-2235071.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          alt="Traditional sarees on display"
        />
        <div className="absolute inset-0 bg-primary-900 opacity-30"></div>
        <div className="absolute inset-0 flex items-end justify-start p-12">
          <div className="text-white">
            <h2 className="text-4xl font-bold mb-2">Welcome</h2>
            <p className="text-xl max-w-xl">Manage your premium saree collection with our sophisticated billing system</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthLayout;