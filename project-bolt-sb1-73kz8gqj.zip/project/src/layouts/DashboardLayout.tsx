import React, { useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  LayoutDashboard, 
  Package, 
  QrCode, 
  Users, 
  Receipt, 
  Settings, 
  Menu, 
  X, 
  ChevronDown, 
  LogOut, 
  User,
  Layers
} from 'lucide-react';

const DashboardLayout: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  
  const isAdmin = currentUser?.role === 'admin';
  
  const closeSidebar = () => setSidebarOpen(false);
  
  // Navigation items
  const navItems = [
    { 
      name: 'Dashboard', 
      path: '/dashboard', 
      icon: <LayoutDashboard size={20} />,
      admin: true
    },
    { 
      name: 'Stock', 
      path: '/stock', 
      icon: <Package size={20} />,
      admin: true
    },
    { 
      name: 'QR Codes', 
      path: '/qrcodes', 
      icon: <QrCode size={20} />,
      admin: true
    },
    { 
      name: 'Staff', 
      path: '/staff', 
      icon: <Users size={20} />,
      admin: true
    },
    { 
      name: 'Billing', 
      path: '/billing', 
      icon: <Receipt size={20} />,
      admin: false
    },
    { 
      name: 'Settings', 
      path: '/settings', 
      icon: <Settings size={20} />,
      admin: false
    },
  ];
  
  // Filter nav items based on user role
  const filteredNavItems = navItems.filter(item => !item.admin || isAdmin);
  
  // Get current page information for breadcrumbs
  const getCurrentPageName = () => {
    const path = location.pathname.substring(1);
    
    if (path === '') return 'Dashboard';
    
    return path.charAt(0).toUpperCase() + path.slice(1);
  };
  
  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-40 bg-neutral-900 bg-opacity-50 transition-opacity md:hidden"
          onClick={closeSidebar}
        ></div>
      )}
      
      {/* Sidebar for mobile */}
      <div 
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-elevated transform transition-transform ease-in-out duration-300 md:hidden ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex justify-between items-center h-16 px-4 border-b border-neutral-200">
          <Link to="/" className="flex items-center">
            <div className="p-1 bg-primary-100 rounded mr-2">
              <Layers size={24} className="text-primary-600" />
            </div>
            <span className="text-xl font-semibold text-primary-900">Saree Shop</span>
          </Link>
          <button 
            onClick={closeSidebar}
            className="text-neutral-500 hover:text-neutral-700 focus:outline-none"
          >
            <X size={24} />
          </button>
        </div>
        
        <div className="h-0 flex-1 overflow-y-auto pt-5 pb-4">
          <nav className="px-2 space-y-1">
            {filteredNavItems.map((item) => (
              <NavLink
                key={item.name}
                to={item.path}
                onClick={closeSidebar}
                className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
              >
                {item.icon}
                <span>{item.name}</span>
              </NavLink>
            ))}
          </nav>
        </div>
      </div>
      
      {/* Sidebar for desktop */}
      <div className="hidden md:flex md:flex-col md:fixed md:inset-y-0 md:w-64 bg-white shadow-soft">
        <div className="flex-1 flex flex-col min-h-0 border-r border-neutral-200">
          <div className="flex items-center h-16 px-4 border-b border-neutral-200">
            <Link to="/" className="flex items-center">
              <div className="p-1 bg-primary-100 rounded mr-2">
                <Layers size={24} className="text-primary-600" />
              </div>
              <span className="text-xl font-semibold text-primary-900">Saree Shop</span>
            </Link>
          </div>
          
          <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
            <nav className="flex-1 px-4 space-y-1">
              {filteredNavItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
                >
                  {item.icon}
                  <span>{item.name}</span>
                </NavLink>
              ))}
            </nav>
          </div>
        </div>
      </div>
      
      {/* Main content */}
      <div className="md:pl-64">
        <div className="sticky top-0 z-10 bg-white shadow-sm">
          <div className="flex justify-between items-center h-16 px-4 md:px-8">
            {/* Mobile menu button */}
            <button
              type="button"
              className="inline-flex items-center justify-center rounded-md text-neutral-500 hover:text-neutral-900 focus:outline-none md:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu size={24} />
            </button>
            
            {/* Breadcrumb */}
            <div className="flex-1 px-4 md:px-0">
              <div className="flex items-center text-sm text-neutral-600">
                <Link 
                  to="/" 
                  className="hover:text-primary-600 transition-colors"
                >
                  Home
                </Link>
                <span className="px-2">/</span>
                <span className="font-medium text-neutral-900">
                  {getCurrentPageName()}
                </span>
              </div>
            </div>
            
            {/* Profile dropdown */}
            <div className="relative">
              <button
                className="flex items-center text-sm px-2 py-1 rounded-lg border border-transparent hover:bg-neutral-100 transition-colors"
                onClick={() => setUserMenuOpen(!userMenuOpen)}
              >
                <div className="w-8 h-8 rounded-full overflow-hidden bg-neutral-200 mr-2">
                  {currentUser?.avatarUrl ? (
                    <img 
                      src={currentUser.avatarUrl} 
                      alt={currentUser.name} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-primary-100 text-primary-600">
                      <User size={16} />
                    </div>
                  )}
                </div>
                <span className="hidden md:block font-medium">{currentUser?.name}</span>
                <ChevronDown size={16} className="ml-1" />
              </button>
              
              {userMenuOpen && (
                <div 
                  className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-elevated py-1 z-10 animate-fade-in"
                  onBlur={() => setUserMenuOpen(false)}
                >
                  <div className="px-4 py-2 border-b border-neutral-200">
                    <p className="text-sm font-medium">{currentUser?.name}</p>
                    <p className="text-xs text-neutral-500">{currentUser?.email}</p>
                  </div>
                  <Link 
                    to="/settings" 
                    className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100 transition-colors"
                    onClick={() => setUserMenuOpen(false)}
                  >
                    <div className="flex items-center">
                      <Settings size={16} className="mr-2" />
                      Settings
                    </div>
                  </Link>
                  <button 
                    className="block w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100 transition-colors"
                    onClick={() => {
                      logout();
                      setUserMenuOpen(false);
                    }}
                  >
                    <div className="flex items-center">
                      <LogOut size={16} className="mr-2" />
                      Logout
                    </div>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
        
        <main className="py-6 px-4 sm:px-6 md:px-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;