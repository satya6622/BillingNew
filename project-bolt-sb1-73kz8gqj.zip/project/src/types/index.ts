export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'staff';
  avatarUrl?: string;
}

export interface SareeItem {
  id: string;
  name: string;
  sku: string;
  price: number;
  quantity: number;
  description?: string;
  imageUrl?: string;
  qrCodeUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BillItem {
  id: string;
  sareeId: string;
  name: string;
  price: number;
  quantity: number;
  subtotal: number;
}

export interface Customer {
  name: string;
  contact: string;
  email?: string;
  whatsapp?: string;
}

export interface Bill {
  id: string;
  billNumber: string;
  customer: Customer;
  items: BillItem[];
  subtotal: number;
  gstAmount: number;
  total: number;
  createdBy: string;
  createdAt: string;
}

export interface StaffMember {
  id: string;
  name: string;
  email: string;
  mobile: string;
  role: 'admin' | 'staff';
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface QrCode {
  id: string;
  sareeId: string;
  sareeName: string;
  price: number;
  imageUrl: string;
  generatedAt: string;
}

export interface SalesSummary {
  todayTotal: number;
  todayBills: number;
  todayGst: number;
  weekTotal: number;
  monthTotal: number;
}

export interface RecentActivity {
  id: string;
  type: 'bill' | 'stock' | 'staff';
  action: string;
  user: string;
  details: string;
  timestamp: string;
}