import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';

// Layout components
import AuthLayout from './layouts/AuthLayout';
import DashboardLayout from './layouts/DashboardLayout';

// Auth pages
import LoginPage from './pages/auth/LoginPage';

// Dashboard pages
import DashboardPage from './pages/dashboard/DashboardPage';
import StockPage from './pages/stock/StockPage';
import QrCodesPage from './pages/qrcodes/QrCodesPage';
import StaffPage from './pages/staff/StaffPage';
import BillingPage from './pages/billing/BillingPage';
import SettingsPage from './pages/settings/SettingsPage';

// Route protection components
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

const AdminRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  
  if (!currentUser || currentUser.role !== 'admin') {
    return <Navigate to="/billing" replace />;
  }
  
  return <>{children}</>;
};

function App() {
  const { currentUser } = useAuth();

  return (
    <Routes>
      {/* Auth routes */}
      <Route element={<AuthLayout />}>
        <Route path="/login" element={
          currentUser 
            ? <Navigate to={currentUser.role === 'admin' ? '/dashboard' : '/billing'} replace /> 
            : <LoginPage />
        } />
      </Route>

      {/* Dashboard routes */}
      <Route element={
        <ProtectedRoute>
          <DashboardLayout />
        </ProtectedRoute>
      }>
        <Route path="/dashboard" element={
          <AdminRoute>
            <DashboardPage />
          </AdminRoute>
        } />
        <Route path="/stock" element={
          <AdminRoute>
            <StockPage />
          </AdminRoute>
        } />
        <Route path="/qrcodes" element={
          <AdminRoute>
            <QrCodesPage />
          </AdminRoute>
        } />
        <Route path="/staff" element={
          <AdminRoute>
            <StaffPage />
          </AdminRoute>
        } />
        <Route path="/billing" element={<BillingPage />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Route>

      {/* Redirect root to login or dashboard based on auth */}
      <Route path="/" element={
        currentUser 
          ? <Navigate to={currentUser.role === 'admin' ? '/dashboard' : '/billing'} replace /> 
          : <Navigate to="/login" replace />
      } />

      {/* 404 catch all */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;